---
name: Question
about: Ask a question about dokka
title: ''
labels: question
assignees: ''

---

**Question**
Your question

**Screenshots**
If applicable, add screenshots to help explain your problem

**Installation**
- Operating system: macOS/Windows/Linux
- Build tool: Gradle v6.8.0/Maven/Cli/3rd party plugin
- Dokka version: 1.4.30

**Additional context**
Add any other context about the problem here
