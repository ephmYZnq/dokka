dependencies {
    implementation(project(":core:test-api"))
    implementation(kotlin("stdlib-jdk8"))
    implementation(kotlin("reflect"))
    implementation("com.willowtreeapps.assertk:assertk-jvm:0.23.1")
}
