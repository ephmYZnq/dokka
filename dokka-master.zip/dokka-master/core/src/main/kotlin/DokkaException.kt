package org.jetbrains.dokka

open class DokkaException(message: String) : RuntimeException(message)
