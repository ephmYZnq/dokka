package org.jetbrains.dokka.pages

interface MultimoduleRootPage : ContentPage

interface ModulePage : ContentPage

interface PackagePage : ContentPage

interface ClasslikePage : ContentPage

interface MemberPage : ContentPage