@Strictfp class Foo() {}
