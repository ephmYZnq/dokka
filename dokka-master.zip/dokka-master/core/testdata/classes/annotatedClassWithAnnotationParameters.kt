@Deprecated("should no longer be used") class Foo() {}
