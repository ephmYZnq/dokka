class Klass() {
    companion object {
        val x = 1

        fun foo() {}
    }
}
