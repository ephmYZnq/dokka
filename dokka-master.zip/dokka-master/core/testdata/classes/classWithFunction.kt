class Klass {
    fun fn() {
    }
}
