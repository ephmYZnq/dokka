class Klass {
    val name: String = ""
}