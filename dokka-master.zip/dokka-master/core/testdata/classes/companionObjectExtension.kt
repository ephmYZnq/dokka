class Foo {
    companion object Default {
    }
}


/**
 * The def
 */
val Foo.Default.x: Int get() = 1
