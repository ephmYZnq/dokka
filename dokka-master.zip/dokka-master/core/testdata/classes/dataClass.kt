data class Foo() {}
