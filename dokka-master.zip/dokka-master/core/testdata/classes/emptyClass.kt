class Klass {

}