class Klass<T> {

}