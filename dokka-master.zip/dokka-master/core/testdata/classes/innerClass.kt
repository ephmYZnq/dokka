class C {
    inner class D {

    }
}