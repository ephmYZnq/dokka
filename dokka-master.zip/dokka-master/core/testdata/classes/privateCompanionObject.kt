package p

class Clz {
    private companion object {
        fun fuun() {

        }

        val aaaa = 0
    }
}