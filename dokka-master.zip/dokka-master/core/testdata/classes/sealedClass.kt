sealed class Foo() {}
