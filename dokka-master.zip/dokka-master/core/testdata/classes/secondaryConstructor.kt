class C() {
    /** This is a secondary constructor. */
    constructor(s: String): this() {
    }
}
