/**
 * Useful
 */
@SinceKotlin("1.1")
class `Since1.1`