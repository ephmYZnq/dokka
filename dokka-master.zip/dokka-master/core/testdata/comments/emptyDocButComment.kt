/* comment */
val property = "test"