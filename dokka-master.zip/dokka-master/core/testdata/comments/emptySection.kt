
/**
 * Summary
 * @one
 */
val property = "test"