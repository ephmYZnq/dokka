/** doc */
val property = "test"