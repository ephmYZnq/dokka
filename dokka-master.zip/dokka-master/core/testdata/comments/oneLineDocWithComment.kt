/** doc */
// comment
val property = "test"