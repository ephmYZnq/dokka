/** doc */

val property = "test"