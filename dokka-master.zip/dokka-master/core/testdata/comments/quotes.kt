/** it's "useful" */
val property = "test"