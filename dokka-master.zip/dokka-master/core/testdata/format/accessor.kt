class C() {
    var x: String
        /** The getter returns an empty string. */ get() = ""
        /** The setter does nothing. */ set(value) { }
}
