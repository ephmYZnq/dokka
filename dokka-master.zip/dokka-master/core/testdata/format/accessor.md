[test](../../index.md) / [C](index.md) / [x](./x.md)

# x

`var x: String`

**Getter**

The getter returns an empty string.

**Setter**

The setter does nothing.

