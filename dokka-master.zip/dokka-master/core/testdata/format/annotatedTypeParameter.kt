public fun <E> containsAll(elements: Collection<@UnsafeVariance E>): @UnsafeVariance E {
}
