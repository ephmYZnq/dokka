[test](../index.md) / [containsAll](./contains-all.md)

# containsAll

`fun <E> containsAll(elements: Collection<@UnsafeVariance `[`E`](contains-all.md#E)`>): @UnsafeVariance `[`E`](contains-all.md#E)