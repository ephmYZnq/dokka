annotation class fancy
