[test](../../index.md) / [fancy](./index.md)

# fancy

`annotation class fancy`

### Constructors

| [&lt;init&gt;](-init-.md) | `fancy()` |

