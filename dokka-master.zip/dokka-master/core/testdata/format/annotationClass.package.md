[test](../index.md)

## Package &lt;root&gt;

### Annotations

| [fancy](fancy/index.md) | `annotation class fancy` |

