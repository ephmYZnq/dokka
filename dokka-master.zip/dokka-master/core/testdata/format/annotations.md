[test](../../index.md) / [Foo](./index.md)

# Foo

`data class Foo`

### Constructors

| [&lt;init&gt;](-init-.md) | `Foo()` |

### Properties

| [x](x.md) | `val x: Int` |

### Functions

| [bar](bar.md) | `fun bar(notInlined: () -> Unit): Unit` |

