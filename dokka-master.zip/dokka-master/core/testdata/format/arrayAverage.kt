class XArray<T>

fun XArray<out Byte>.average(): Double = 0.0
fun XArray<out Double>.average(): Double = 0.0
fun XArray<out Float>.average(): Double = 0.0
fun XArray<out Int>.average(): Double = 0.0
fun XArray<out Long>.average(): Double = 0.0
fun XArray<out Short>.average(): Double = 0.0
