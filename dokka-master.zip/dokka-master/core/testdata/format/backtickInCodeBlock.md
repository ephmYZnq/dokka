[test](../index.md) / [foo](./foo.md)

# foo

`fun foo(): Unit`

bt : `` ` ``

bt+ : ``prefix ` postfix``

backslash: `\`

