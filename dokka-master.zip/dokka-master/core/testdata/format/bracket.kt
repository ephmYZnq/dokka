/**
 * bar[]
 */
fun foo() {}
