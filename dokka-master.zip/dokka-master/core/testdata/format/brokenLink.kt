/**
 * This references [noSuchIdentifier].
 */
fun f() { }
