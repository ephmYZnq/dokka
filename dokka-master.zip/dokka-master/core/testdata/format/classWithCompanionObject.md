[test](../../index.md) / [Klass](./index.md)

# Klass

`class Klass`

### Constructors

| [&lt;init&gt;](-init-.md) | `Klass()` |

### Companion Object Properties

| [x](x.md) | `val x: Int` |

### Companion Object Functions

| [foo](foo.md) | `fun foo(): Unit` |

