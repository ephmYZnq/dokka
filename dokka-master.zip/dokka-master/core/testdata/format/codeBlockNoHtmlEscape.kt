/**
 * Try to make this check pass
 * ```
 * if(1 > 2)
 * ```
 * Or just piece of html
 * ```
 * <p>1 = 3</p>
 * ```
 */
fun hackTheArithmetic(){
    valueOf(1) {
        set(3)
    }
}