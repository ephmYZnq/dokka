[test](../index.md) / [hackTheArithmetic](./hack-the-arithmetic.md)

# hackTheArithmetic

`fun hackTheArithmetic(): Unit`

Try to make this check pass

```
if(1 > 2)
```

Or just piece of html

```
<p>1 = 3</p>
```

