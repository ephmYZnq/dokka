
interface Bar

/**
 * Correct ref [Foo.Companion]
 */
class Foo {
    companion object : Bar
}