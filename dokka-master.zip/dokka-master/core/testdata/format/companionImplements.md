[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo`

Correct ref [Foo.Companion](-companion.md)

### Types

| [Companion](-companion.md) | `companion object Companion : `[`Bar`](../-bar.md) |

### Constructors

| [&lt;init&gt;](-init-.md) | Correct ref [Foo.Companion](-companion.md)`Foo()` |

