class Foo {
    companion object Default {
    }
}


/**
 * The default object property.
 */
val Foo.Default.x: Int get() = 1
