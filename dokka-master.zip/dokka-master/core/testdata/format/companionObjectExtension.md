[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo`

### Constructors

| [&lt;init&gt;](-init-.md) | `Foo()` |

### Companion Object Extension Properties

| [x](../x.md) | The default object property.`val Foo.Default.x: Int` |

