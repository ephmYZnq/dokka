package test

/**
 * See [xyzzy]
 */
class Bar(): Foo()
