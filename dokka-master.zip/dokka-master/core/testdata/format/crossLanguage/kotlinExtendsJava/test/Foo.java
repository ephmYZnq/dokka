package test;

public class Foo {
  public void xyzzy() {
  }
}
