@Deprecated("This class sucks") class C() { }

@Deprecated("This function sucks") fun f() { }

@Deprecated("This property sucks") val p: Int get() = 0
