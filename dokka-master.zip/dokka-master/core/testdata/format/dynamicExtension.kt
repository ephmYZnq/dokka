class Foo

fun dynamic.bar() {}
