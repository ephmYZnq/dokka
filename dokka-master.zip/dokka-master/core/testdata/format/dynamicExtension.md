[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo`

### Constructors

| [&lt;init&gt;](-init-.md) | `Foo()` |

