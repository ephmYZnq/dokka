fun foo(): dynamic = ""

