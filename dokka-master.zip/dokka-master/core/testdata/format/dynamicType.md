[test](../index.md) / [foo](./foo.md)

# foo

`fun foo(): dynamic`