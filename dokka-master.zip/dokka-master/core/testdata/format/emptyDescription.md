[test](../index.md) / [fn](./fn.md)

# fn

`fun fn(): Unit`

Function fn

