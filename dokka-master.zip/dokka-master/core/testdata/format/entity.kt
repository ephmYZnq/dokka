/**
 * Copyright &copy; JetBrains 2015 &#x22;
 */
class Bar {}
