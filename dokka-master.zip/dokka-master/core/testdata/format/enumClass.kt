public enum class InlineOption {
    ONLY_LOCAL_RETURN,
    LOCAL_CONTINUE_AND_BREAK
}
