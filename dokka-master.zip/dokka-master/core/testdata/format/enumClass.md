[test](../../index.md) / [InlineOption](./index.md)

# InlineOption

`enum class InlineOption`

### Enum Values

| [ONLY_LOCAL_RETURN](-o-n-l-y_-l-o-c-a-l_-r-e-t-u-r-n.md) |  |
| [LOCAL_CONTINUE_AND_BREAK](-l-o-c-a-l_-c-o-n-t-i-n-u-e_-a-n-d_-b-r-e-a-k.md) |  |

