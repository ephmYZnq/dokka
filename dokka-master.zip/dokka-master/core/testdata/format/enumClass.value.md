[test](../../index.md) / [InlineOption](index.md) / [LOCAL_CONTINUE_AND_BREAK](./-l-o-c-a-l_-c-o-n-t-i-n-u-e_-a-n-d_-b-r-e-a-k.md)

# LOCAL_CONTINUE_AND_BREAK

`LOCAL_CONTINUE_AND_BREAK`