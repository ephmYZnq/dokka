/**
 * [java.math.RoundingMode.UP]
 */
fun f() {}