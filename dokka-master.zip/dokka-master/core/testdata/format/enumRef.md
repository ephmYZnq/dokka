[test](../index.md) / [f](./f.md)

# f

`fun f(): Unit`

[java.math.RoundingMode.UP](https://docs.oracle.com/javase/6/docs/api/java/math/RoundingMode.html#UP)

