class MyException : Exception
