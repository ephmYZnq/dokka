[test](../../index.md) / [MyException](./index.md)

# MyException

`class MyException : Exception`

### Constructors

| [&lt;init&gt;](-init-.md) | `MyException()` |

