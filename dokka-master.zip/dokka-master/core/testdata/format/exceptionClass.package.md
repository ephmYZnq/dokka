[test](../index.md)

## Package &lt;root&gt;

### Exceptions

| [MyException](-my-exception/index.md) | `class MyException : Exception` |

