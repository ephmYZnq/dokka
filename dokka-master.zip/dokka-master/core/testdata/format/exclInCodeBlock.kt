/**
 * The magic word is `!`
 */
fun foo() {
}
