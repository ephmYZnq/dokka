[test](../index.md) / [test](./test.md)

# test

`fun test(): Unit`

Correct link: [Foo.ext](ext.md)

