/**
 * Function with receiver
 * @receiver must be a non-empty string
 */
fun String.fn() {
}
