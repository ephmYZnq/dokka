[test](../../index.md) / [kotlin.String](index.md) / [fn](./fn.md)

# fn

`fun String.fn(): Unit`

Function with receiver

**Receiver**
must be a non-empty string

