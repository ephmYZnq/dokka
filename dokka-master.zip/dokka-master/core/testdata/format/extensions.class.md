[test](../../index.md) / [foo](../index.md) / [kotlin.String](./index.md)

### Extensions for kotlin.String

| [fn](fn.md) | Function with receiver`fun String.fn(): Unit`<br>`fun String.fn(x: Int): Unit` |
| [foobar](foobar.md) | Property with receiver.`val String.foobar: Int` |

