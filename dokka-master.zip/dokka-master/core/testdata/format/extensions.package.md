[test](../index.md) / [foo](./index.md)

## Package foo

### Extensions for External Classes

| [kotlin.String](kotlin.-string/index.md) |  |

