/**
 * It is link to [example site][example.com]
 *
 * Sure, it is [example.com]
 *
 * [example.com]: https://example.com
 */
fun a() {

}