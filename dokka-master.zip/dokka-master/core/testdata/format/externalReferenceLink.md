[test](../index.md) / [a](./a.md)

# a

`fun a(): Unit`

It is link to [example site](https://example.com)

Sure, it is [example.com](https://example.com)

