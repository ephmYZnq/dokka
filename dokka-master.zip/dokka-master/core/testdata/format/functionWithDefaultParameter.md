[test](../index.md) / [f](./f.md)

# f

`fun f(x: String = ""): Unit`