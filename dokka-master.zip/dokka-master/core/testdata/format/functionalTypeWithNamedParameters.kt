class A
class B
class C

val f: (a: A, b: B) -> C = { a, b -> C() }

fun acceptFunctionTypeWithNamedArguments(f: (bb: B, aa: A) -> C) {

}