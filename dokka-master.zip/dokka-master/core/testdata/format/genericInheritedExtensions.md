[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar<T> : `[`Foo`](../-foo/index.md)`<`[`T`](index.md#T)`>`

### Constructors

| [&lt;init&gt;](-init-.md) | `Bar()` |

### Extension Functions

| [first](../first.md) | `fun <T> `[`Foo`](../-foo/index.md)`<`[`T`](../first.md#T)`>.first(): Unit` |
| [second](../second.md) | `fun <T> `[`Bar`](./index.md)`<`[`T`](../second.md#T)`>.second(): Unit` |

