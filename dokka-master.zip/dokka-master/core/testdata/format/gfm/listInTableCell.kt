class Foo {
    /**
     * 1. Foo
     * 1. Bar
     */
    fun foo() {
    }
}
