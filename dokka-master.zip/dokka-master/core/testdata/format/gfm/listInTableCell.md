[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Foo()` |

### Functions

| Name | Summary |
|---|---|
| [foo](foo.md) | <ol><li>Foo</li><li>Bar</li></ol>`fun foo(): Unit` |
