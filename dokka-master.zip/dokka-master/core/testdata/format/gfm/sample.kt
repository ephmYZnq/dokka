/**
 * The class Foo.
 */
class Foo {
    /**
     * The method bar.
     */
    fun bar() {

    }

    /**
     * The method baz.
     */
    fun baz() {

    }
}