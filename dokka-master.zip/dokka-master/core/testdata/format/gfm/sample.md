[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo`

The class Foo.

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | The class Foo.`Foo()` |

### Functions

| Name | Summary |
|---|---|
| [bar](bar.md) | The method bar.`fun bar(): Unit` |
| [baz](baz.md) | The method baz.`fun baz(): Unit` |
