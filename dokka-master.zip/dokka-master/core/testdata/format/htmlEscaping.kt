/**
 * Special characters: < is "less than", > is "greater than", & is "ampersand"
 */
fun x<T>(): T?  = null
