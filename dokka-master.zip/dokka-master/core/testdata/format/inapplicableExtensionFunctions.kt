open class Foo<T> {
}

class Bar : Foo<Char>() {
}

fun Foo<Int>.shazam() {
}

fun Bar.xyzzy() {
}
