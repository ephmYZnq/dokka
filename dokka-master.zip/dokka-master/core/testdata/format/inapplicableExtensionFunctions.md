[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar : `[`Foo`](../-foo/index.md)`<Char>`

### Constructors

| [&lt;init&gt;](-init-.md) | `Bar()` |

### Extension Functions

| [xyzzy](../xyzzy.md) | `fun `[`Bar`](./index.md)`.xyzzy(): Unit` |

