/**
 * Create a new Foo value as follows:
 *
 *    val foo = Foo.create {
 *        type { "ABC" }
 *    }
 */
fun foo() {

}