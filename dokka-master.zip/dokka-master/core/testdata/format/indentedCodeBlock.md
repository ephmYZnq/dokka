[test](../index.md) / [foo](./foo.md)

# foo

`fun foo(): Unit`

Create a new Foo value as follows:

```
    val foo = Foo.create {
        type { "ABC" }
    }
```

