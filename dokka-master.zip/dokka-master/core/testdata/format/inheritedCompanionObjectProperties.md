[test](../../index.md) / [C](./index.md)

# C

`class C : `[`A`](../-a/index.md)

### Types

| [Companion](-companion/index.md) | `companion object Companion : `[`B`](../-b/index.md) |

### Constructors

| [&lt;init&gt;](-init-.md) | `C()` |

### Functions

| [xyzzy](xyzzy.md) | `fun xyzzy(): Unit` |

### Inherited Functions

| [foo](../-a/foo.md) | `fun foo(): Unit` |

### Companion Object Functions

| [shazam](shazam.md) | `fun shazam(): Unit` |

### Inherited Companion Object Functions

| [bar](../-b/bar.md) | `fun bar(): Unit` |

