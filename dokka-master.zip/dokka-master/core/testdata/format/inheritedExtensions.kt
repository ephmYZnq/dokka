open class Foo

class Bar : Foo()

fun Foo.first() {

}

fun Bar.second() {

}
