[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar : `[`Foo`](../-foo/index.md)

### Constructors

| [&lt;init&gt;](-init-.md) | `Bar()` |

### Extension Functions

| [first](../first.md) | `fun `[`Foo`](../-foo/index.md)`.first(): Unit` |
| [second](../second.md) | `fun `[`Bar`](./index.md)`.second(): Unit` |

