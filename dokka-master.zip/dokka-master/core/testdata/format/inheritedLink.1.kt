package p1

import java.util.LinkedList

interface Foo {

    /** Says hello - [LinkedList]. */
    fun sayHello() : String

}