package p2

import p1.Foo

class FooBar : Foo {

    override fun sayHello(): String {
        return "Hello!"
    }

}