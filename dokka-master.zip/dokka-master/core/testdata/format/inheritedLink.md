<!-- File: test/p2/-foo-bar/-init-.md -->
[test](../../index.md) / [p2](../index.md) / [FooBar](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`FooBar()`
<!-- File: test/p2/-foo-bar/say-hello.md -->
[test](../../index.md) / [p2](../index.md) / [FooBar](index.md) / [sayHello](./say-hello.md)

# sayHello

`fun sayHello(): String`

Overrides [Foo.sayHello](../../p1/-foo/say-hello.md)

Says hello - [LinkedList](https://docs.oracle.com/javase/6/docs/api/java/util/LinkedList.html).

