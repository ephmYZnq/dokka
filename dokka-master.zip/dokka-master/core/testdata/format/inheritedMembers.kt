open class Foo {
    fun first() {
    }

    val firstProp: Int = 0
}

class Bar : Foo() {
    fun second()

    val secondProp: Int = 1
}
