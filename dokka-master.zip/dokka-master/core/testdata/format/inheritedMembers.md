[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar : `[`Foo`](../-foo/index.md)

### Constructors

| [&lt;init&gt;](-init-.md) | `Bar()` |

### Properties

| [secondProp](second-prop.md) | `val secondProp: Int` |

### Inherited Properties

| [firstProp](../-foo/first-prop.md) | `val firstProp: Int` |

### Functions

| [second](second.md) | `fun second(): Unit` |

### Inherited Functions

| [first](../-foo/first.md) | `fun first(): Unit` |

