/**
 * returns 1
 */
inline suspend fun foo(a: () -> String): Int {
    1
}
