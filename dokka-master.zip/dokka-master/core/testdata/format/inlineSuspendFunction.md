[test](../index.md) / [foo](./foo.md)

# foo

`suspend inline fun foo(a: () -> String): Int`

returns 1

