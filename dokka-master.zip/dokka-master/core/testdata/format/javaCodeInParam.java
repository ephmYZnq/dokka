class C {

    /**
     * @param par this is {@code some code} and other text
     */
    public void withParam(String par) {}
}
