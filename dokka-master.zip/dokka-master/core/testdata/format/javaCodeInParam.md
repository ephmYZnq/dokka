[test](../../index.md) / [C](index.md) / [withParam](./with-param.md)

# withParam

`open fun withParam(par: String!): Unit`

### Parameters

`par` - String!: this is `some code` and other text