/**
 * <p>{@code A<B>C}</p>
 * <p>{@literal A<B>C}</p>
 */
class C {
}
