[test](../../index.md) / [C](./index.md)

# C

`protected open class C`

`A<B>C`



A&lt;B&gt;C

### Constructors

| [&lt;init&gt;](-init-.md) | `A<B>C``C()` |

