class Foo {
  /** @deprecated  use {@link #bar} instead */
  public void foo() {}
  public void bar() {}
}
