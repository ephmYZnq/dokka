/**
 * Call {@link #bar()} to do the job.
 */
class Foo {
  public void bar()
}
