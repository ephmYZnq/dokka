/**
 * Call {@link #bar() this wonderful method} to do the job.
 */
class Foo {
  public void bar()
}
