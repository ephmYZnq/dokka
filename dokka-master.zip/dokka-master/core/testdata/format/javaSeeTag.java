/**
 * @see #bar
 */
public class Foo {
  public void bar() {}
}