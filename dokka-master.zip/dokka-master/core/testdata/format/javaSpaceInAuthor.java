/**
 * @author Dmitry Jemerov
 */
class C {
}