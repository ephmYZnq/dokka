[test](../../index.md) / [C](./index.md)

# C

`protected open class C`

**Author**
Dmitry Jemerov

### Constructors

| [&lt;init&gt;](-init-.md) | `C()` |

