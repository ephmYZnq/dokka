/**
 * <b>Bold</b>
 * <strong>Strong</strong>
 * <i>Italic</i>
 * <em>Emphasized</em>
 * <p>Paragraph</p>
 * <s>Strikethrough</s>
 * <del>Deleted</del>
 * <code>Code</code>
 * <pre>Block code</pre>
 * <ul><li>List Item</li></ul>
 * <pre>
 * with( some ) {
 *    multi = lines
 *    sample()
 * }
 * </pre>
 * <pre>
 * {@code
 *  with (some) { <code> }
 * }
 * </pre>
 *
 */
public class C {
}
