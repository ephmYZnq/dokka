[test](../../index.md) / [C](./index.md)

# C

`open class C`

**Bold** **Strong** *Italic* *Emphasized*

Paragraph

 ~~Strikethrough~~ ~~Deleted~~ `Code`

```
Block code
```

 * List Item


```

  with( some ) {
     multi = lines
     sample()
  }
  ```



```
with (some) { <code> }
  
  ```

### Constructors

| [&lt;init&gt;](-init-.md) | **Bold** **Strong** *Italic* *Emphasized* `C()` |

