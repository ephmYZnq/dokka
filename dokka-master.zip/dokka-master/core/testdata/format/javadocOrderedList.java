/**
 * <ol>
 *   <li>Rinse</li>
 *   <li>Repeat</li>
 * </ol>
 */
public class Bar {
}
