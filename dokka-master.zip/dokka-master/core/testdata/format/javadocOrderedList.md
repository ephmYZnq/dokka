[test](../../index.md) / [Bar](./index.md)

# Bar

`open class Bar`

 1. Rinse
 2. Repeat


### Constructors

| [&lt;init&gt;](-init-.md) |
1. Rinse
 2. Repeat
 <br>`Bar()` |

