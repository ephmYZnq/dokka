/**
 * This is a [ClassLoader] and I can get its [ClassLoader.getResource]
 *
 * You can print something to [java.lang.System.out] now!
 */
class C : ClassLoader {
}
