/**
 * Use [this method][Bar.foo] for best results.
 */
class Bar {
    fun foo() {}
}
