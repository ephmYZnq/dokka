object KClassLoader {
    fun foo(c: Enum<*>) { }
}
