/**
 * An emphasised class.
 *
 * _This class [Bar] is awesome._
 *
 * _Even more awesomer is the function [Bar.foo]_
 *
 * _[Bar.hello] is also OK_
 */
class Bar {
    fun foo() {}
    fun hello() {}
}
