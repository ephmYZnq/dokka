/**
 * Some class with really useless documentation.
 *
 * # Beer o'clock - time to go to the [Bar]
 *
 * ## But __is [it](isitbeeroclock.com)__ really?
 *
 * ### [Bar.hello] to the [Bar.world]!
 *
 * #### _Kotlin is amazing, [Bar.none]_
 *
 * ##### We need to go [Bar.deeper]
 *
 * ###### End of the [Bar.line] - we need to go back!
 */
class Bar {
    fun foo() {}
    fun hello() {}
    fun world() {}
    fun kotlin() {}
    fun none() {}
    fun deeper() {}
    fun line() {}
}
