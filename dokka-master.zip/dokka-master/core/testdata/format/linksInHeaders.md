[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar`

Some class with really useless documentation.

# Beer o'clock - time to go to the [Bar](./index.md)

## But **is [it](isitbeeroclock.com)** really?

### [Bar.hello](hello.md) to the [Bar.world](world.md)!

#### *Kotlin is amazing, [Bar.none](none.md)*

##### We need to go [Bar.deeper](deeper.md)

###### End of the [Bar.line](line.md) - we need to go back!

### Constructors

| [&lt;init&gt;](-init-.md) | Some class with really useless documentation.`Bar()` |

### Functions

| [deeper](deeper.md) | `fun deeper(): Unit` |
| [foo](foo.md) | `fun foo(): Unit` |
| [hello](hello.md) | `fun hello(): Unit` |
| [kotlin](kotlin.md) | `fun kotlin(): Unit` |
| [line](line.md) | `fun line(): Unit` |
| [none](none.md) | `fun none(): Unit` |
| [world](world.md) | `fun world(): Unit` |

