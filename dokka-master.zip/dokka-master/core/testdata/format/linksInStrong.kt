/**
 * A strong class.
 *
 * __This class [Bar] is awesome.__
 *
 * __Even more awesomer is the function [Bar.foo]__
 *
 * __[Bar.hello] is also OK__
 */
class Bar {
    fun foo() {}
    fun hello() {}
}
