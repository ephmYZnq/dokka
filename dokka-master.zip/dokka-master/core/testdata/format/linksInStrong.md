[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar`

A strong class.

**This class [Bar](./index.md) is awesome.**

**Even more awesomer is the function [Bar.foo](foo.md)**

**[Bar.hello](hello.md) is also OK**

### Constructors

| [&lt;init&gt;](-init-.md) | A strong class.`Bar()` |

### Functions

| [foo](foo.md) | `fun foo(): Unit` |
| [hello](hello.md) | `fun hello(): Unit` |

