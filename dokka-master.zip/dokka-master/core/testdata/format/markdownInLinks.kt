/**
 * [a**b**__d__ kas ](https://www.ibm.com)
 */
fun foo() {}
