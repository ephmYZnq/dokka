open class X

class Foo : X

class Bar {
    fun X.y() = ""
    fun Foo.x() = ""
}
