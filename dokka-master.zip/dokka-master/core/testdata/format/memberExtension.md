[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo : `[`X`](../-x/index.md)

### Constructors

| [&lt;init&gt;](-init-.md) | `Foo()` |

