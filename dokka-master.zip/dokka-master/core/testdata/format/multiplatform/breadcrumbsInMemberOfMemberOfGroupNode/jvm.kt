package pack

class SomeCoolJvmClass {
    fun magic() {

    }
}

typealias Some = SomeCoolJvmClass