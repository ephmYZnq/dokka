[test](../../index.md) / [pack](../index.md) / [Some](index.md) / [magic](./magic.md)

# magic

(JS) `fun magic(): Unit`