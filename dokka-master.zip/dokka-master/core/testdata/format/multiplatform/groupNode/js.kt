package pack

class Some {

    fun magic() {

    }
}