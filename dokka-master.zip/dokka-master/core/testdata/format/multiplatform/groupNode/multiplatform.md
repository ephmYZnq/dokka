[test](../../index.md) / [pack](../index.md) / [Some](./index.md)

# Some

(JVM) `typealias Some = SomeCoolJvmClass`(JS) `class Some`

### Constructors

| (JS) [&lt;init&gt;](-init-.md) | `Some()` |

### Functions

| (JS) [magic](magic.md) | `fun magic(): Unit` |

