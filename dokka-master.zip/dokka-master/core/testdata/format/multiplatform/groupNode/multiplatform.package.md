[test](../index.md) / [pack](./index.md)

## Package pack

### Types

| [Some](-some/index.md) | (JVM) `typealias Some = SomeCoolJvmClass`<br>(JS) `class Some` |
| (JVM) [SomeCoolJvmClass](-some-cool-jvm-class/index.md) | `class SomeCoolJvmClass` |

