[test](../../index.md) / [foo](../index.md) / [Foo](./index.md)

# Foo

(JVM, JS) `class Foo`

This is a foo.

### Constructors

| (JVM, JS) [&lt;init&gt;](-init-.md) | This is a foo.`<init>()` |

### Properties

| (JS) [propJs](prop-js.md) | `val propJs: String` |
| (JVM) [propJvm](prop-jvm.md) | `val propJvm: String` |
| (JVM, JS) [propJvmAndJs](prop-jvm-and-js.md) | `val propJvmAndJs: Int` |

### Functions

| (JVM, JS) [bothJvmAndJs](both-jvm-and-js.md) | `fun bothJvmAndJs(): Unit` |
| (JS) [js](js.md) | `fun js(): Unit` |
| (JVM) [jvm](jvm.md) | `fun jvm(): Unit` |

