package foo

/**
 * This is a foo.
 */
class Foo {
    fun bothJvmAndJs() {
    }

    fun js() {
    }

    val propJvmAndJs = 0

    val propJs = "abc"
}
