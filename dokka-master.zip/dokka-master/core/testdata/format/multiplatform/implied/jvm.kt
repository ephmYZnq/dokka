package foo

/**
 * This is a foo.
 */
class Foo {
    fun bothJvmAndJs() {
    }

    fun jvm() {
    }

    val propJvmAndJs = 0

    val propJvm = "abc"
}
