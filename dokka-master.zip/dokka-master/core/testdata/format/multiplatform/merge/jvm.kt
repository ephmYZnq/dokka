package foo

/**
 * This is a foo.
 */
class Foo {

}
