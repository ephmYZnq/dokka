[test](../index.md) / [foo](./index.md)

## Package foo

### Types

| (JVM, JS) [Foo](-foo/index.md) | This is a foo.`class Foo` |

