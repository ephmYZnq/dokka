[test](../../index.md) / [foo](../index.md) / [Foo](./index.md)

# Foo

(JVM) `class Foo`

This is a foo.

### Constructors

| (JVM) [&lt;init&gt;](-init-.md) | This is a foo.`Foo()` |

### Properties

| (JVM) [propJvm](prop-jvm.md) | `val propJvm: String` |

### Functions

| (JVM) [jvm](jvm.md) | `fun jvm(): Unit` |

