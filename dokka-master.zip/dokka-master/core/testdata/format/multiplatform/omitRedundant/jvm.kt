package foo

/**
 * This is a foo.
 */
class Foo {
    fun jvm() {
    }

    val propJvm = "abc"
}
