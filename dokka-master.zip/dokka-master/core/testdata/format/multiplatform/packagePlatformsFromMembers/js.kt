package foo.bar

fun buz() {}
