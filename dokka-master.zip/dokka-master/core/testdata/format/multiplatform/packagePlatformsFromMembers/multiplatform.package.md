[test](../index.md) / [foo.bar](./index.md)

## Package foo.bar

### Functions

| (JVM, JS) [buz](buz.md) | `fun buz(): Unit` |

