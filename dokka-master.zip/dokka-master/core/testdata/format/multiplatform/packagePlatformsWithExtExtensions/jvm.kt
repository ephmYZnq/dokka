package some

fun String.buz(): Unit {

}