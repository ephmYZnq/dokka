[test](../index.md) / [some](./index.md)

## Package some

### Extensions for External Classes

| (JVM) [kotlin.String](kotlin.-string/index.md) |  |

