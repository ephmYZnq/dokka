package foo

/**
 * This is a bar.
 */
class Bar {
}
