[test](../index.md) / [foo](./index.md)

## Package foo

### Types

| (JS) [Bar](-bar/index.md) | This is a bar.`class Bar` |
| (JVM) [Foo](-foo/index.md) | This is a foo.`class Foo` |

