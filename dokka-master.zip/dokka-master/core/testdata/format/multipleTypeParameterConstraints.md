<!-- File: test/--root--/-a.md -->
[test](../index.md) / [A](./-a.md)

# A

`interface A`
<!-- File: test/--root--/-b.md -->
[test](../index.md) / [B](./-b.md)

# B

`interface B`
<!-- File: test/--root--/f.md -->
[test](../index.md) / [f](./f.md)

# f

`fun <T> f(): Unit where T : `[`A`](-a.md)`, T : `[`B`](-b.md)