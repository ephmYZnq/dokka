/**
 * There is `long long int` story
 * full of
 * new lines
 */
class A