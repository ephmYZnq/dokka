[test](../index.md) / [foo](./foo.md)

# foo

`fun foo(): Unit`

Correct ref [TA](-a/index.md)
Correct ref [TB](-b/index.md)

