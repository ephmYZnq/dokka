class C<T> {
    fun foo(): Comparable<T>? {
        return null
    }
}
