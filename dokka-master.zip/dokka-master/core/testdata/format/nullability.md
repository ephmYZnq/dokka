[test](../../index.md) / [C](./index.md)

# C

`class C<T>`

### Constructors

| [&lt;init&gt;](-init-.md) | `C()` |

### Functions

| [foo](foo.md) | `fun foo(): Comparable<`[`T`](index.md#T)`>?` |

