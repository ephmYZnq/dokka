[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar<T>`

### Constructors

| [&lt;init&gt;](-init-.md) | `Bar()` |

### Properties

| [dataList](data-list.md) | `val dataList: MutableList<`[`T`](index.md#T)`>` |

### Functions

| [checkElement](check-element.md) | `fun checkElement(elem: `[`T`](index.md#T)`, addFunc: ((elem: `[`T`](index.md#T)`) -> Unit)? = { dataList.add(it) }): Int` |

