class C {
    fun plus(other: C): C
}
