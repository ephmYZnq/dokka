[test](../../index.md) / [C](index.md) / [plus](./plus.md)

# plus

`fun plus(other: `[`C`](index.md)`): `[`C`](index.md)