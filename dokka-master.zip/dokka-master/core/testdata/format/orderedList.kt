/**
 * Usage instructions:
 *
 * 1. Rinse
 * 1. Repeat
 */
class Bar {
}
