/** Performs an action on x. */
fun f(x: Int) { }

/** Performs an action on x. */
fun f(x: String) { }
