/**
 * Performs an action on x.
 *
 * This is a long description.
 * @param x the int value to perform the action on.
 */
fun f(x: Int) { }

/**
 * Performs an action on x.
 *
 * This is a long description.
 * @param x the string value to perform the action on.
 */
fun f(x: String) { }
