open class C() {
    open fun f() {}
}

class D(): C() {
    override fun f() {}
}
