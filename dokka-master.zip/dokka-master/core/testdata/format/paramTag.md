[test](../index.md) / [f](./f.md)

# f

`fun f(x: String, y: Int): Unit`

### Parameters

`x` - A string

`y` - A number with a really long description that spans multiple lines and goes
    on and on and is very interesting to read