[test](../index.md) / [x](./x.md)

# x

`var x: Int`