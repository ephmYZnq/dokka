/**
 * See [kotlin.apply] for the docs
 */
fun foo() {

}