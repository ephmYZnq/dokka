open class Foo {
}

fun <T : Foo> T.xyzzy() {
}
