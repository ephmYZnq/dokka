[test](../../index.md) / [Foo](./index.md)

# Foo

`open class Foo`

### Constructors

| [&lt;init&gt;](-init-.md) | `Foo()` |

### Extension Functions

| [xyzzy](../xyzzy.md) | `fun <T : `[`Foo`](./index.md)`> `[`T`](../xyzzy.md#T)`.xyzzy(): Unit` |

