/**
 * Prints [this]
 */
fun String.some() {
    println(this)
}