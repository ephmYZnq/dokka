[test](../../index.md) / [kotlin.String](./index.md)

### Extensions for kotlin.String

| [some](some.md) | Prints [this](some/-this-.md)`fun String.some(): Unit` |

