package example

/**
 * It is link to [example other func][example]
 *
 * Sure, it is [example]
 *
 * [example]: example.someOtherFunc
 */
fun a() {

}

fun someOtherFunc() {

}