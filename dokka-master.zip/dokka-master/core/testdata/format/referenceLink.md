<!-- File: test/example/a.md -->
[test](../index.md) / [example](index.md) / [a](./a.md)

# a

`fun a(): Unit`

It is link to [example other func](some-other-func.md)

Sure, it is [example](some-other-func.md)

<!-- File: test/example/some-other-func.md -->
[test](../index.md) / [example](index.md) / [someOtherFunc](./some-other-func.md)

# someOtherFunc

`fun someOtherFunc(): Unit`