inline fun f<reified T>(a: () -> String) {

}
