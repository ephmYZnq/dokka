[test](../index.md) / [f](./f.md)

# f

`inline fun <reified T> f(a: () -> String): Unit`