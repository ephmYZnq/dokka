fun (suspend () -> Unit).foo() {

}