[test](../../index.md) / [kotlin.coroutines.SuspendFunction0](./index.md)

### Extensions for kotlin.coroutines.SuspendFunction0

| [foo](foo.md) | `fun (suspend () -> Unit).foo(): Unit` |

