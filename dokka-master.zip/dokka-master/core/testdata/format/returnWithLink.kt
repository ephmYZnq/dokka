/**
 * @return Returns [s1] and does nothing else.
 */
fun foo(s1: String) = s1