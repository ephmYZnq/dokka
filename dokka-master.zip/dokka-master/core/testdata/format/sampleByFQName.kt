package test

fun sample() {
    println("sample")
}

/**
 * @sample test.sample
 */
fun use() {

}