<!-- File: test/test/sample.md -->
[test](../index.md) / [test](index.md) / [sample](./sample.md)

# sample

`fun sample(): Unit`
<!-- File: test/test/use.md -->
[test](../index.md) / [test](index.md) / [use](./use.md)

# use

`fun use(): Unit`

``` kotlin
println("sample")
```

