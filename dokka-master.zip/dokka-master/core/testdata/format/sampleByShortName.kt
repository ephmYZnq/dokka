package test

fun sample() {
    println("sample")
}

/**
 * @sample sample
 */
fun use() {

}