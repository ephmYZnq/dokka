/**
 * @see foo
 * @see bar
 */
fun quux() {
}

fun foo() {
}

fun bar() {
}