open class Foo {
}

class Bar : Foo() {
}

fun Foo.xyzzy() {
}

fun Foo.shazam() {

}

fun Bar.xyzzy() {
}

fun Bar.shazam(i: Int) {
}
