[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar : `[`Foo`](../-foo/index.md)

### Constructors

| [&lt;init&gt;](-init-.md) | `Bar()` |

### Extension Functions

| [shazam](../shazam.md) | `fun `[`Bar`](./index.md)`.shazam(i: Int): Unit`<br>`fun `[`Foo`](../-foo/index.md)`.shazam(): Unit` |
| [xyzzy](../xyzzy.md) | `fun `[`Bar`](./index.md)`.xyzzy(): Unit` |

