[test](../../index.md) / [Since1.1](./index.md)

# Since1.1

`class Since1.1`

Useful

### Constructors

| [&lt;init&gt;](-init-.md)Since: `1.1` | Useful`Since1.1()` |

