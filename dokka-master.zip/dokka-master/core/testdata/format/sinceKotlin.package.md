[test](../index.md)

## Package &lt;root&gt;

### Types

| [Since1.1](-since1.1/index.md) (Since: `1.1`) | Useful`class Since1.1` |

