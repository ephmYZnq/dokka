/**
 * Useful
 */
@SinceKotlin("1.1")
class `Since1.1`

/**
 * Useful also
 */
@SinceKotlin("1.2")
class `Since1.2`