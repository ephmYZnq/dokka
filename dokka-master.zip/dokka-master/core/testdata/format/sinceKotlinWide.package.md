[test](../index.md)

## Package &lt;root&gt;

### Types

| [Since1.1](-since1.1/index.md) (Since: `1.1`) | Useful`class Since1.1` |
| [Since1.2](-since1.2/index.md) (Since: `1.2`) | Useful also`class Since1.2` |

