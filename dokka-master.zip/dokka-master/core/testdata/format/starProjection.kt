public fun Iterable<*>.containsFoo(element: Any?): Boolean {
    return false
}
