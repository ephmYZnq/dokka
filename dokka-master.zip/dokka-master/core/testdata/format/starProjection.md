[test](../../index.md) / [kotlin.collections.Iterable](./index.md)

### Extensions for kotlin.collections.Iterable

| [containsFoo](contains-foo.md) | `fun Iterable<*>.containsFoo(element: Any?): Boolean` |

