[test](../index.md) / [kotlin](./index.md)

## Package kotlin

### Types

| [Array](-array/index.md) | `class Array<T>` |
| [CharArray](-char-array/index.md) | `class CharArray` |
| [IntArray](-int-array/index.md) | `class IntArray` |

### Properties

| [foo](foo.md) | Returns true if foo.`val <T> any_array<T>.foo: Int` |

