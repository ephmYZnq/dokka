/**
 * returns 1
 */
suspend inline fun foo(): Int {
    1
}
