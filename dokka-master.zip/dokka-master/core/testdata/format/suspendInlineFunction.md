[test](../index.md) / [foo](./foo.md)

# foo

`suspend fun foo(): Int`

returns 1

