[test](../index.md) / [takesSuspendParam](./takes-suspend-param.md)

# takesSuspendParam

`fun takesSuspendParam(func: suspend () -> Unit): Unit`