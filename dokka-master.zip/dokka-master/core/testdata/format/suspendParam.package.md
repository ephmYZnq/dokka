[test](../index.md)

## Package &lt;root&gt;

### Functions

| [takesSuspendParam](takes-suspend-param.md) | `fun takesSuspendParam(func: suspend () -> Unit): Unit` |

