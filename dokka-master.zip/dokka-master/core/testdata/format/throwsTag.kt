/**
 * @throws IllegalArgumentException on Mondays
 * @exception NullPointerException on Tuesdays
 */
fun f() {}
