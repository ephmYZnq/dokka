[test](../index.md) / [f](./f.md)

# f

`fun f(): Unit`

### Exceptions

`IllegalArgumentException` - on Mondays

`NullPointerException` - on Tuesdays