/**
 * Another emphasised class.
 *
 * _This class, [Bar] is just meh._
 *
 * _For a semicolon; [Bar.foo] is for you!._
 */
class Bar {
    fun foo() = ";"
}
