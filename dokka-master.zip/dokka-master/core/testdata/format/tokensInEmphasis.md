[test](../../index.md) / [Bar](./index.md)

# Bar

`class Bar`

Another emphasised class.

*This class, [Bar](./index.md) is just meh.*

*For a semicolon; [Bar.foo](foo.md) is for you!.*

### Constructors

| [&lt;init&gt;](-init-.md) | Another emphasised class.`Bar()` |

### Functions

| [foo](foo.md) | `fun foo(): String` |

