/**
 * Why did the token cross the road?
 *
 * # Because it was Beer o'clock @ [The.bar]
 *
 * ## But __waz *\[sic\]* [it](isitbeeroclock.com)__ really?
 *
 * ### [The.bar] has? [The.foo]est drinks ever!
 *
 * #### _[The.kotlinz] is [The.bestests], [Bar.none]_
 *
 * ##### So many lame code "puns" (in) [The.house]
 *
 * ###### End of the?? [Bar.line]! - we need to go back!
 */
class The {
    object Bar {
        fun none() {}
    }

    fun bar() {}
    fun foo() {}
    fun bestests() {}
    fun kotlinz() {}
    fun house() {}
    fun line() {}
}
