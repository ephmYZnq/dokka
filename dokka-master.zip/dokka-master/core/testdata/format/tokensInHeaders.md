[test](../../index.md) / [The](./index.md)

# The

`class The`

Why did the token cross the road?

# Because it was Beer o'clock @ [The.bar](bar.md)

## But **waz *\[sic\]* [it](isitbeeroclock.com)** really?

### [The.bar](bar.md) has? [The.foo](foo.md)est drinks ever!

#### *[The.kotlinz](kotlinz.md) is [The.bestests](bestests.md), [Bar.none](-bar/none.md)*

##### So many lame code "puns" (in) [The.house](house.md)

###### End of the?? [Bar.line](#)! - we need to go back!

### Types

| [Bar](-bar/index.md) | `object Bar` |

### Constructors

| [&lt;init&gt;](-init-.md) | Why did the token cross the road?`The()` |

### Functions

| [bar](bar.md) | `fun bar(): Unit` |
| [bestests](bestests.md) | `fun bestests(): Unit` |
| [foo](foo.md) | `fun foo(): Unit` |
| [house](house.md) | `fun house(): Unit` |
| [kotlinz](kotlinz.md) | `fun kotlinz(): Unit` |
| [line](line.md) | `fun line(): Unit` |

