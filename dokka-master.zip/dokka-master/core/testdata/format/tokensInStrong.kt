/**
 * __YASC: [Yasc] Yet Another Strong Class__
 *
 * __This class, [Yasc] *is* just meh.__
 *
 * __For a semicolon; [Yasc.foo] is for you!.__
 */
class Yasc {
    fun foo() = ";"
}
