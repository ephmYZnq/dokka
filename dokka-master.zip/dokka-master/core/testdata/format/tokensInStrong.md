[test](../../index.md) / [Yasc](./index.md)

# Yasc

`class Yasc`

**YASC: [Yasc](./index.md) Yet Another Strong Class**

**This class, [Yasc](./index.md) *is* just meh.**

**For a semicolon; [Yasc.foo](foo.md) is for you!.**

### Constructors

| [&lt;init&gt;](-init-.md) | **YASC: [Yasc](./index.md) Yet Another Strong Class**`Yasc()` |

### Functions

| [foo](foo.md) | `fun foo(): String` |

