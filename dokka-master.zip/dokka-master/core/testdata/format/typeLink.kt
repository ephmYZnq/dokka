class Foo() {
}

class Bar(): Foo {
}
