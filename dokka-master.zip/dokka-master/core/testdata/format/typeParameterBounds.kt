
/**
 * generic function
 * @param T the first type parameter
 */
public fun <T : R, R> generic() {
}