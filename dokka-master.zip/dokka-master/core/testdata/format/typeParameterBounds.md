[test](../index.md) / [generic](./generic.md)

# generic

`fun <T : `[`R`](generic.md#R)`, R> generic(): Unit`

generic function

### Parameters

`T` - the first type parameter