/**
 * Correct ref to [T]
 */
fun <T> T.tt() {
    println("T.tt")
}