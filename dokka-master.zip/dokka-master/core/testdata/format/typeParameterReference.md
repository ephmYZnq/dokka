[test](../index.md) / [tt](./tt.md)

# tt

`fun <T> `[`T`](tt.md#T)`.tt(): Unit`

Correct ref to [T](tt.md#T)

