/**
 * @param T the class parameter type
 */
class Foo<out T> {
}
