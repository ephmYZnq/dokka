[test](../../index.md) / [Foo](./index.md)

# Foo

`class Foo<out T>`

### Parameters

`T` - the class parameter type

### Constructors

| [&lt;init&gt;](-init-.md) | `Foo()` |

