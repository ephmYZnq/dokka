fun <T> Array<out T>.foo() {}
