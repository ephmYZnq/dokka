[test](../../index.md) / [kotlin.Array](./index.md)

### Extensions for kotlin.Array

| [foo](foo.md) | `fun <T> Array<out `[`T`](foo.md#T)`>.foo(): Unit` |

