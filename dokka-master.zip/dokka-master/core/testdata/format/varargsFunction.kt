fun f(vararg s: String) {}
