[test](../index.md) / [f](./f.md)

# f

`fun f(vararg s: String): Unit`