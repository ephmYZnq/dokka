package foo

@SinceKotlin("1.1")
fun jre7New() {}

fun jre7() {}

fun shared() {}

@SinceKotlin("1.1")
fun sharedNew() {}