package foo

@SinceKotlin("1.1")
fun jsNew() {}

fun js() {}

fun shared() {}

@SinceKotlin("1.1")
fun sharedNew() {}