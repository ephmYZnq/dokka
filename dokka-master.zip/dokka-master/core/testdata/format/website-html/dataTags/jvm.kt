package foo

@SinceKotlin("1.1")
fun jvmNew() {}

fun jvm() {}

fun shared() {}

@SinceKotlin("1.1")
fun sharedNew() {}