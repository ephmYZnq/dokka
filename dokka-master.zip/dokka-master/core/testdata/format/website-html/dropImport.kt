import samples.*
import some.*

/**
 * @sample example1
 */
fun foo() {
}

fun example1() {

}