/**
 * @param spell The text of spell, often distributed on scrolls
 * @return Spell ID for future casts
 */
fun magic(spell: String): Int {

}

/**
 * @param spell Spell ID of previously casted spell
 * @return Spell ID for future casts
 */
fun magic(spell: Int): Int {

}