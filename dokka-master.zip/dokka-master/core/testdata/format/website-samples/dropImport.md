---
title: foo - test
layout: api
---

<div class='api-docs-breadcrumbs'><a href="test/index">test</a> / <a href="test/foo">foo</a></div>

# foo

<div class="signature"><code><span class="keyword">fun </span><span class="identifier">foo</span><span class="symbol">(</span><span class="symbol">)</span><span class="symbol">: </span><span class="identifier">Unit</span></code></div>
<div class="sample" markdown="1">

``` kotlin
import some.*

fun main(args: Array<String>) {
//sampleStart

//sampleEnd
}
```

</div>
