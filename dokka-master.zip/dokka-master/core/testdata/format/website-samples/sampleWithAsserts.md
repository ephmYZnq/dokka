---
title: a - test
layout: api
---

<div class='api-docs-breadcrumbs'><a href="test/index">test</a> / <a href="test/a">a</a></div>

# a

<div class="signature"><code><span class="keyword">fun </span><span class="identifier">a</span><span class="symbol">(</span><span class="symbol">)</span><span class="symbol">: </span><span class="identifier">String</span></code></div>
<div class="sample" markdown="1">

``` kotlin


fun main(args: Array<String>) {
//sampleStart
println(a()) // Hello, Work
println("a() == b() is ${a() == b()}") // true
//sampleEnd
}
```

</div>
