---
title: pack.Some - test
layout: api
---

<div class='api-docs-breadcrumbs'><a href="test/index">test</a> / <a href="test/pack/index">pack</a> / <a href="test/pack/-some/index">Some</a></div>

# Some

<div class="overload-group" data-platform="JVM" markdown="1">

<div class="signature"><code><span class="keyword">typealias </span><span class="identifier">Some</span>&nbsp;<span class="symbol">=</span>&nbsp;<span class="identifier">SomeCoolJvmClass</span></code></div>

**Platform and version requirements:** JVM

</div>

<div class="overload-group" data-platform="JS" markdown="1">

<div class="signature"><code><span class="keyword">class </span><span class="identifier">Some</span></code></div>

**Platform and version requirements:** JS

### Constructors

<table class="api-docs-table">
<tbody>
<tr>
<td markdown="1">
<a href="test/pack/-some/-some/-init-">&lt;init&gt;</a>
</td>
<td markdown="1">
<div class="signature"><code><span class="identifier">Some</span><span class="symbol">(</span><span class="symbol">)</span></code></div>

</td>
</tr>
</tbody>
</table>

### Functions

<table class="api-docs-table">
<tbody>
<tr>
<td markdown="1">
<a href="test/pack/-some/-some/magic">magic</a>
</td>
<td markdown="1">
<div class="signature"><code><span class="keyword">fun </span><span class="identifier">magic</span><span class="symbol">(</span><span class="symbol">)</span><span class="symbol">: </span><span class="identifier">Unit</span></code></div>

</td>
</tr>
</tbody>
</table>

</div>
