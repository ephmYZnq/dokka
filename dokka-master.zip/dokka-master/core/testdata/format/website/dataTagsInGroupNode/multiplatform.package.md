---
title: pack - test
layout: api
---

<div class='api-docs-breadcrumbs'><a href="test/index">test</a> / <a href="test/pack/index">pack</a></div>

## Package pack

### Types

<table class="api-docs-table">
<tbody>
<tr data-platform="JS"><td markdown="1">
<a href="test/pack/-some/index">Some</a>
</td>
<td markdown="1">
<div class="signature"><code><span class="keyword">class </span><span class="identifier">Some</span></code></div>

</td>
</tr><tr data-platform="JVM"><td markdown="1">
<a href="test/pack/-some-cool-jvm-class/index">SomeCoolJvmClass</a>
</td>
<td markdown="1">
<div class="signature"><code><span class="keyword">class </span><span class="identifier">SomeCoolJvmClass</span></code></div>

</td>
</tr></tbody>
</table>

### Type Aliases

<table class="api-docs-table">
<tbody>
<tr data-platform="JVM"><td markdown="1">
<a href="test/pack/-some/index">Some</a>
</td>
<td markdown="1">
<div class="signature"><code><span class="keyword">typealias </span><span class="identifier">Some</span>&nbsp;<span class="symbol">=</span>&nbsp;<span class="identifier">SomeCoolJvmClass</span></code></div>

</td>
</tr></tbody>
</table>
