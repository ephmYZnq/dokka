@Strictfp fun f() {
}
