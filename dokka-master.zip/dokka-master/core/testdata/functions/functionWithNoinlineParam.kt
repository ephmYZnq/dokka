fun function(noinline notInlined: () -> Unit) {
}
