/**
 * Multiline
 *
 * Function
 * Documentation
 */
fun function(/** parameter */ x: Int) {
}