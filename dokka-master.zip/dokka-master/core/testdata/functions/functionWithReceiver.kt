/**
 * Function with receiver
 */
fun String.fn() {
}

/**
 * Function with receiver
 */
fun String.fn(x: Int) {
}
