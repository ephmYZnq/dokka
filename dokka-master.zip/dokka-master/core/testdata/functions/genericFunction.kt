
/**
 * generic function
 */
private fun <T> generic() {}