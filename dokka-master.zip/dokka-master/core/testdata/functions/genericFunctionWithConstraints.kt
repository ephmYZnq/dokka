
/**
 * generic function
 */
public fun <T : R, R> generic() {
}