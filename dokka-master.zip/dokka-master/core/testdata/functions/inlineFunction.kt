inline fun f(a: () -> String) {
}
