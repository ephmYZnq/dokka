inline suspend fun f(a: () -> String) {
}
