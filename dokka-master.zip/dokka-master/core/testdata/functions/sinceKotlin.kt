/**
 * Quite useful [String]
 */
@SinceKotlin("1.1")
fun `availableSince1.1`(): String = "1.1 rulezz"