suspend inline fun f(a: () -> String) {
}
