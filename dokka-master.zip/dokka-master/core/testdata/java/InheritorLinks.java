public class InheritorLinks {
  public static class Foo {
  }

  public static class Bar extends Foo {
  }
}
