class InnerClass {
    public class D {
    }
}
