class Test {
    public String[] arrayToString(int[] data) {
      return null;
    }
}
