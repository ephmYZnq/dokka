public class Constants {
    public static final String constStr = "some value";
    public static final Object nullConst = null;
    public static final String refConst = constStr;
}