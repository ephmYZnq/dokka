class Test {
  public Test() {}

  public Test(String s) {}
}
