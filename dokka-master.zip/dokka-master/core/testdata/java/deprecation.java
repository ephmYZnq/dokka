class C {
  /**
   * @deprecated This should no longer be used
   */
  void fn() {}
}