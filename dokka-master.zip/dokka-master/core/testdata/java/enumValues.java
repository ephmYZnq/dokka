enum E {
  Foo
}