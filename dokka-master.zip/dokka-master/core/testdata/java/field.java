class Test {
  public int i;
  public static final String s;
}
