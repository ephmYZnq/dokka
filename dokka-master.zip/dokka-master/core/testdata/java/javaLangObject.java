class Test {
  public Object fn() { return null; }
}
