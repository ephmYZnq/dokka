class Test {
    /**
     * Summary for Function
     * @param name is String parameter
     * @param value is int parameter
     * @author yole
     */
    public void fn(String name, int value) {

    }
}