class C {
  public static void foo() {
  }
}
