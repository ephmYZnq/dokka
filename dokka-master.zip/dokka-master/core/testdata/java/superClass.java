public class Foo extends Exception implements Cloneable {
}
