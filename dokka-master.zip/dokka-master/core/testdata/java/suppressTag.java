class C {
  public static void foo() {
  }

  /**
   * @suppress
   */
  public static void bar() {
  }
}
