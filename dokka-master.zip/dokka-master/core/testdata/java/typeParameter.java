class Foo<T extends Comparable<T>> {
     public <E> E foo();
}
