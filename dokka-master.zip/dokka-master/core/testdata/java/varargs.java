class Foo {
     public void bar(String... x);
}
