/**
 * [error]
 */
fun argNamedError(error: String) {}