package foo

class ByteArray {
    fun foo(): IntArray {
        return intArrayOf()
    }
}