package foo


/**
 * Linking to [test]
 */
class TestClass {

    companion object {

        @JvmStatic fun test(arg: String) {}
    }
}