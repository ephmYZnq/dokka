package foo

/**
 * Description
 *
 * @constructor print peach
 */
class Peach {
    init {
        println("peach")
    }
}