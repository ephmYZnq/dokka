package foo

class MyException : Exception {
    fun foo() = ""
}
