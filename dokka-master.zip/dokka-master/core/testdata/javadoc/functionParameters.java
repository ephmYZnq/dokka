package bar;

/**
 * Foo
 */

public class Foo {

    /** perfom request
     *
     * @param name user name
     * @param password user password
     */
    public void request(String name, String password) {

    }
}