package foo

class Apple {
    @get:JvmName("_tree")
    internal val source: Tree
}
