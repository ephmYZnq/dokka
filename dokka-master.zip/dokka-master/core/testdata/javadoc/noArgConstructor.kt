package foo

/**
 * Description
 *
 * @constructor print plum
 */
class Plum() {
    init {
        println("plum")
    }
}