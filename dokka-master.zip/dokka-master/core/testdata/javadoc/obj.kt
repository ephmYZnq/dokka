package foo

class O {
    companion object {

    }
}
