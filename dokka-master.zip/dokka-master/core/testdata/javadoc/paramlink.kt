package demo

/**
 * You can [eat] it or cut it into slices using [cutIntoPieces]
 */
interface Apple {
    fun eat()

    fun cutIntoPieces(pieces: Int)
}
