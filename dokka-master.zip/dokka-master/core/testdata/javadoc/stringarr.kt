package foo

class Foo {
    companion object {
        @JvmStatic fun main(args: Array<String>) {
        }
    }
}