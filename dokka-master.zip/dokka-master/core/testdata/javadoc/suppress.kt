/**
 * @suppress
 */
class Some {

}


/**
 * @suppress
 * @author me
 * @see other
 */
class SomeAgain {

}

class Same {
    /**
     * @suppress
     */
    fun privateApi() {

    }

    /**
     * @suppress
     */
    val privateForSomeReason = ""
}

/**
 * @suppress
 */
interface Interface {

}