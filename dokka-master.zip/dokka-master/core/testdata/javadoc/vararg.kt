fun vararg(a: String, vararg b: Int) {}

fun varargInMiddle(a: String, vararg b: Int, c: Short) {}