/**
 * This is link to [MY_CONSTANT_VALUE]
 */
class Foo {
    companion object {
        val MY_CONSTANT_VALUE = 0
    }
}