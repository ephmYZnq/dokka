/**
 * This is link to [http://example.com/#example]
 */
class Foo {}